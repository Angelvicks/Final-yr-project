- To run the program you must have the following:
  * Python 3 installed in your machine. 
  
  * A python editor 
  
  * tkinter installed in your machine which usually comes with python as default but if not prsent use the following command
   - sudo apt-get python3-tk
   
   * Then you can run the code in your chosen python editor
   
   * In case you cannot run the code you have to install the missing libraries found in the code that is PIL. 
-The project contains to .py files;
 
 *The project.py display the circles and arrows of the prpojects. It also has buttons that permit the user to write on the canvas and erase as well. 
 
 *The Mousemove.py displays the circles and arrows but give the possiblity to the user to displace each object or arrow on the canvas screen.
